import {
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { COR_METODO, CORES, pct, rotuloConfianca } from '../formato'

function DicaDist({ active, payload }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  return (
    <div className="tooltip">
      <div className="t-data">retorno {pct(p.retorno)}</div>
      <div>
        densidade empírica <strong>{p.densidade.toFixed(1)}</strong>
      </div>
      <div style={{ color: 'rgba(255,255,255,0.55)' }}>normal equivalente {p.normal.toFixed(1)}</div>
    </div>
  )
}

export default function GraficoDistribuicao({ dados }) {
  const { distribuicao, metodos, ordem_metodos, parametros, estatisticas } = dados
  const conf = rotuloConfianca(parametros.confianca)

  // o corte do método empírico define a cauda pintada
  const corteEmpirico = -metodos.empirico.var_percentual

  // encaixa cada VaR no centro de bin mais próximo, para a linha cair no eixo
  const maisProximo = (alvo) =>
    distribuicao.reduce(
      (melhor, d) => (Math.abs(d.retorno - alvo) < Math.abs(melhor - alvo) ? d.retorno : melhor),
      distribuicao[0]?.retorno ?? 0
    )

  return (
    <div className="cartao">
      <h3>Distribuição dos retornos e os cortes de cada método</h3>
      <p className="legenda">
        Histograma dos {estatisticas.observacoes} retornos observados da carteira. A cauda pintada
        é a fatia de {pct(1 - parametros.confianca, 1)} além do VaR empírico. A linha clara é a
        normal de mesma média e desvio — o paramétrico enxerga só ela; o empírico enxerga as
        barras. Quando as linhas verticais se separam, é a curtose aparecendo.
      </p>
      <ResponsiveContainer width="100%" height={300}>
        <ComposedChart data={distribuicao} margin={{ top: 20, right: 12, bottom: 4, left: -18 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis
            dataKey="retorno"
            tickFormatter={(v) => `${(v * 100).toFixed(1).replace('.', ',')}%`}
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
            minTickGap={34}
          />
          <YAxis
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip content={<DicaDist />} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
          <Bar dataKey="densidade" isAnimationActive={false}>
            {distribuicao.map((d, i) => (
              <Cell
                key={i}
                fill={d.retorno <= corteEmpirico ? CORES.vermelhoClaro : CORES.vinho}
                fillOpacity={d.retorno <= corteEmpirico ? 0.95 : 0.85}
              />
            ))}
          </Bar>
          <Line
            type="monotone"
            dataKey="normal"
            stroke="rgba(255,255,255,0.45)"
            strokeWidth={1.5}
            dot={false}
            isAnimationActive={false}
          />
          {ordem_metodos.map((nome, i) => (
            <ReferenceLine
              key={nome}
              x={maisProximo(-metodos[nome].var_percentual)}
              stroke={COR_METODO[nome]}
              strokeDasharray="4 4"
              label={{
                value: `${metodos[nome].rotulo} ${conf}`,
                position: 'insideTop',
                fill: COR_METODO[nome],
                fontSize: 10.5,
                dy: i * 15,
              }}
            />
          ))}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
