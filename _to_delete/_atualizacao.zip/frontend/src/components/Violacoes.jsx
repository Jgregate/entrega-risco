import { useMemo, useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { COR_METODO, dataCurta, num, pct } from '../formato'

function DicaAno({ active, payload, label }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  return (
    <div className="tooltip">
      <div className="t-data">{label}</div>
      {payload.map((s) => (
        <div key={s.dataKey} style={{ color: s.color }}>
          {s.name}: {s.value} violações
        </div>
      ))}
      <div style={{ color: 'rgba(255,255,255,0.55)', marginTop: 3 }}>
        esperadas: {p.esperadas.toFixed(1)} em {p.pregoes} pregões
      </div>
    </div>
  )
}

export function ViolacoesPorAno({ dados }) {
  const { metodos, ordem_metodos, parametros } = dados
  const alpha = 1 - parametros.confianca

  const porAno = useMemo(() => {
    const mapa = new Map()
    for (const nome of ordem_metodos) {
      for (const d of metodos[nome].backtest.serie) {
        const ano = d.data.slice(0, 4)
        const linha = mapa.get(ano) || { ano, pregoes: 0 }
        if (nome === ordem_metodos[0]) linha.pregoes += 1
        linha[nome] = (linha[nome] || 0) + (d.violacao ? 1 : 0)
        mapa.set(ano, linha)
      }
    }
    return [...mapa.values()]
      .map((a) => ({ ...a, esperadas: a.pregoes * alpha }))
      .sort((a, b) => a.ano.localeCompare(b.ano))
  }, [metodos, ordem_metodos, alpha])

  const mediaEsperada =
    porAno.reduce((s, a) => s + a.esperadas, 0) / Math.max(porAno.length, 1)

  return (
    <div className="cartao">
      <h3>Violações por ano</h3>
      <p className="legenda">
        Barras acima da linha tracejada são anos em que o método furou mais que o previsto —
        tipicamente estresse que a janela histórica ainda não tinha absorvido. A linha marca a
        média anual esperada ({num(mediaEsperada, 1)} violações).
      </p>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={porAno} margin={{ top: 8, right: 12, bottom: 0, left: -24 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis
            dataKey="ano"
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
          />
          <YAxis
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            allowDecimals={false}
          />
          <Tooltip content={<DicaAno />} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
          <Legend
            wrapperStyle={{ fontSize: 12, paddingTop: 4 }}
            formatter={(v) => <span style={{ color: 'rgba(255,255,255,0.72)' }}>{v}</span>}
          />
          <ReferenceLine
            y={mediaEsperada}
            stroke="rgba(255,255,255,0.55)"
            strokeDasharray="4 4"
          />
          {ordem_metodos.map((nome) => (
            <Bar
              key={nome}
              dataKey={nome}
              name={metodos[nome].rotulo}
              fill={COR_METODO[nome]}
              radius={[3, 3, 0, 0]}
              maxBarSize={26}
              isAnimationActive={false}
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export function Aderencia({ dados }) {
  const { metodos, ordem_metodos, parametros } = dados
  const alpha = 1 - parametros.confianca
  const [foco, setFoco] = useState(ordem_metodos[0])

  const piores = useMemo(() => {
    const serie = metodos[foco].backtest.serie
    return serie
      .filter((d) => d.violacao)
      .map((d) => ({ ...d, excesso: -(d.retorno - d.var) }))
      .sort((a, b) => b.excesso - a.excesso)
      .slice(0, 8)
  }, [metodos, foco])

  return (
    <div className="cartao">
      <h3>Aderência do modelo</h3>
      <p className="legenda">
        Teste de Kupiec (POF), cobertura incondicional. H₀: a taxa de violações é igual a{' '}
        {pct(alpha, 1)}. p-valor abaixo de 0,05 rejeita H₀ — o modelo está mal calibrado, seja por
        furar demais (subestima risco) ou de menos (capital parado à toa).
      </p>

      <table>
        <thead>
          <tr>
            <th>Método</th>
            <th style={{ textAlign: 'right' }}>Violações</th>
            <th style={{ textAlign: 'right' }}>Taxa obs.</th>
            <th style={{ textAlign: 'right' }}>Maior seq.</th>
            <th style={{ textAlign: 'right' }}>LR</th>
            <th style={{ textAlign: 'right' }}>p-valor</th>
            <th style={{ textAlign: 'right' }}>Veredito</th>
          </tr>
        </thead>
        <tbody>
          {ordem_metodos.map((nome) => {
            const r = metodos[nome].backtest.resumo
            const rejeita = r.kupiec.rejeita_5pct
            return (
              <tr key={nome}>
                <td style={{ color: COR_METODO[nome], fontWeight: 500 }}>
                  {metodos[nome].rotulo}
                </td>
                <td className="num">
                  {r.violacoes} / {num(r.violacoes_esperadas, 1)}
                </td>
                <td className="num">{pct(r.taxa_observada)}</td>
                <td className="num">{r.maior_sequencia}</td>
                <td className="num">{num(r.kupiec.estatistica_lr)}</td>
                <td className="num">{num(r.kupiec.p_valor, 3)}</td>
                <td className="num">
                  <span className={`selo-teste ${rejeita ? 'falha' : 'ok'}`}>
                    {rejeita ? 'rejeita H₀' : 'não rejeita'}
                  </span>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>

      <div className="separador" />

      <div className="segmentado">
        <span className="rotulo" style={{ margin: 0 }}>
          Maiores excessos
        </span>
        {ordem_metodos.map((nome) => (
          <button
            key={nome}
            className={`chip${foco === nome ? ' ativo' : ''}`}
            onClick={() => setFoco(nome)}
            style={foco === nome ? { borderColor: COR_METODO[nome], color: COR_METODO[nome] } : undefined}
          >
            {metodos[nome].rotulo}
          </button>
        ))}
      </div>

      <table>
        <thead>
          <tr>
            <th>Data</th>
            <th style={{ textAlign: 'right' }}>Retorno</th>
            <th style={{ textAlign: 'right' }}>Limite VaR</th>
            <th style={{ textAlign: 'right' }}>Excesso</th>
          </tr>
        </thead>
        <tbody>
          {piores.length === 0 && (
            <tr>
              <td colSpan={4}>Nenhuma violação no período.</td>
            </tr>
          )}
          {piores.map((d) => (
            <tr key={d.data}>
              <td>{dataCurta(d.data)}</td>
              <td className="num perda">{pct(d.retorno)}</td>
              <td className="num">{pct(d.var)}</td>
              <td className="num">{pct(-d.excesso)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
