import { useMemo } from 'react'
import {
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { COR_METODO, dataCurta, pct, rotuloConfianca } from '../formato'

const ROTULOS = { empirico: 'Empírico', parametrico: 'Paramétrico', ewma: 'EWMA' }
// EWMA tracejado: as duas curvas vermelhas se separariam mal só pela cor
const TRACEJADO = { ewma: '5 4' }

function Dica({ active, payload }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  return (
    <div className="tooltip">
      <div className="t-data">{dataCurta(p.data)}</div>
      <div>
        retorno <strong>{pct(p.retorno)}</strong>
      </div>
      {Object.keys(ROTULOS).map((k) =>
        p[k] === undefined ? null : (
          <div key={k} style={{ color: COR_METODO[k] }}>
            {ROTULOS[k]} {pct(p[k])}
            {p[`viol_${k}`] ? ' · violou' : ''}
          </div>
        )
      )}
    </div>
  )
}

/**
 * As três curvas de VaR sobre o mesmo retorno realizado.
 * É aqui que a diferença de comportamento fica visível: o EWMA respira com a
 * volatilidade, o paramétrico acompanha de longe e o empírico anda em degraus
 * — cada degrau é uma perda grande entrando ou saindo da janela.
 */
export default function GraficoComparacaoVaR({ dados }) {
  const { metodos, ordem_metodos, parametros } = dados

  const serie = useMemo(() => {
    const base = new Map()
    for (const nome of ordem_metodos) {
      for (const ponto of metodos[nome].backtest.serie) {
        const linha = base.get(ponto.data) || { data: ponto.data, retorno: ponto.retorno }
        linha[nome] = ponto.var
        linha[`viol_${nome}`] = ponto.violacao
        base.set(ponto.data, linha)
      }
    }
    return [...base.values()].sort((a, b) => a.data.localeCompare(b.data))
  }, [metodos, ordem_metodos])

  return (
    <div className="cartao">
      <h3>Os três VaRs no tempo</h3>
      <p className="legenda">
        Limite de {rotuloConfianca(parametros.confianca)} recalculado a cada pregão com a janela
        móvel dos {parametros.janela_backtest} dias anteriores, sem look-ahead. A linha cinza é o
        retorno realizado: sempre que ela fura uma das curvas, aquele método registra violação.
      </p>
      <ResponsiveContainer width="100%" height={330}>
        <ComposedChart data={serie} margin={{ top: 8, right: 12, bottom: 4, left: -18 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis
            dataKey="data"
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
            minTickGap={60}
            tickFormatter={(v) => v.slice(0, 7)}
          />
          <YAxis
            stroke="rgba(255,255,255,0.35)"
            tick={{ fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
          />
          <Tooltip content={<Dica />} cursor={{ stroke: 'rgba(255,255,255,0.2)' }} />
          <Legend
            wrapperStyle={{ fontSize: 12, paddingTop: 8 }}
            formatter={(v) => <span style={{ color: 'rgba(255,255,255,0.72)' }}>{v}</span>}
          />
          <Line
            type="monotone"
            dataKey="retorno"
            name="retorno realizado"
            stroke="rgba(255,255,255,0.3)"
            strokeWidth={0.9}
            dot={false}
            isAnimationActive={false}
          />
          {ordem_metodos.map((nome) => (
            <Line
              key={nome}
              type="monotone"
              dataKey={nome}
              name={metodos[nome].rotulo}
              stroke={COR_METODO[nome]}
              strokeWidth={1.8}
              strokeDasharray={TRACEJADO[nome]}
              dot={false}
              isAnimationActive={false}
            />
          ))}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
