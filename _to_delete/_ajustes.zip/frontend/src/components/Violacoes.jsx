import { useMemo, useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { COR_METODO, CORES, dataCurta, num, pct } from '../formato'
import CartaoGrafico from './CartaoGrafico'

const JANELAS = [
  { anos: 1, texto: '1 ano' },
  { anos: 2, texto: '2 anos' },
  { anos: 3, texto: '3 anos' },
  { anos: 5, texto: '5 anos' },
]

function DicaJanela({ active, payload, label }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  return (
    <div className="tooltip">
      <div className="t-data">{label}</div>
      <div>
        taxa observada <strong>{pct(p.taxa)}</strong>
      </div>
      <div style={{ color: 'rgba(255,255,255,0.55)' }}>
        {p.violacoes} violações em {p.observacoes} observações
      </div>
      <div style={{ color: 'rgba(255,255,255,0.55)' }}>esperado: {pct(p.esperado)}</div>
    </div>
  )
}

function PainelJanela({ metodo, cor, serie, dominioY, esperado }) {
  const acima = serie.filter((b) => b.taxa > b.esperado).length

  return (
    <CartaoGrafico
      titulo={metodo.rotulo}
      cor={cor}
      altura={220}
      subtitulo={`${acima} de ${serie.length} janelas acima do esperado · taxa no período ${pct(
        metodo.backtest.resumo.taxa_observada
      )}`}
    >
      {(altura) => (
        <ResponsiveContainer width="100%" height={altura}>
          <BarChart data={serie} margin={{ top: 6, right: 8, bottom: 0, left: -14 }}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
            <XAxis
              dataKey="rotulo"
              stroke="rgba(255,255,255,0.35)"
              tick={{ fontSize: 10.5 }}
              tickLine={false}
            />
            <YAxis
              domain={dominioY}
              stroke="rgba(255,255,255,0.35)"
              tick={{ fontSize: 10.5 }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
            />
            <Tooltip content={<DicaJanela />} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
            <ReferenceLine y={esperado} stroke="rgba(255,255,255,0.55)" strokeDasharray="4 4" />
            {/* com poucas janelas a barra fina fica perdida no eixo */}
            <Bar
              dataKey="taxa"
              radius={[3, 3, 0, 0]}
              maxBarSize={serie.length <= 3 ? 110 : 54}
              isAnimationActive={false}
            >
              {serie.map((b, i) => (
                <Cell key={i} fill={cor} fillOpacity={b.taxa > b.esperado ? 1 : 0.45} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
    </CartaoGrafico>
  )
}

/**
 * Violações em TAXA (violações ÷ observações da janela), não em contagem.
 * Em taxa a linha do esperado é a mesma em qualquer tamanho de janela — é o
 * próprio 1 − confiança — então dá para comparar blocos de tamanhos diferentes
 * e métodos diferentes na mesma escala.
 */
export function ViolacoesPorAno({ dados }) {
  const { metodos, ordem_metodos, parametros } = dados
  const esperado = 1 - parametros.confianca
  const [anosPorJanela, setAnosPorJanela] = useState(1)

  const { porMetodo, disponiveis } = useMemo(() => {
    const base = metodos[ordem_metodos[0]].backtest.serie
    const anos = [...new Set(base.map((d) => Number(d.data.slice(0, 4))))].sort()
    const totalAnos = anos.length

    // blocos ancorados no fim: a janela mais recente fica sempre completa
    const blocos = []
    for (let fim = totalAnos; fim > 0; fim -= anosPorJanela) {
      const inicio = Math.max(0, fim - anosPorJanela)
      const doBloco = anos.slice(inicio, fim)
      blocos.unshift({
        anos: new Set(doBloco),
        rotulo:
          doBloco.length === 1
            ? String(doBloco[0])
            : `${doBloco[0]}–${String(doBloco[doBloco.length - 1]).slice(2)}`,
      })
    }

    const saida = {}
    for (const nome of ordem_metodos) {
      const serie = metodos[nome].backtest.serie
      saida[nome] = blocos.map((b) => {
        let observacoes = 0
        let violacoes = 0
        for (const d of serie) {
          if (b.anos.has(Number(d.data.slice(0, 4)))) {
            observacoes += 1
            if (d.violacao) violacoes += 1
          }
        }
        return {
          rotulo: b.rotulo,
          observacoes,
          violacoes,
          taxa: observacoes ? violacoes / observacoes : 0,
          esperado,
        }
      })
    }
    return { porMetodo: saida, disponiveis: totalAnos }
  }, [metodos, ordem_metodos, anosPorJanela, esperado])

  const maxTaxa = Math.max(
    ...ordem_metodos.flatMap((n) => porMetodo[n].map((b) => b.taxa)),
    esperado
  )
  const dominioY = [0, Math.ceil((maxTaxa * 1.12) / 0.01) * 0.01]

  return (
    <section>
      <div className="titulo-secao">
        <h3>Violações por janela</h3>
        <p className="legenda">
          Cada barra é a <strong>taxa de violações</strong> da janela — violações dividido pelo
          número de observações do período — e não a contagem bruta. Em taxa a linha tracejada do
          esperado ({pct(esperado, 1)}) vale para qualquer tamanho de janela, então blocos com mais
          ou menos pregões continuam comparáveis entre si. Barras cheias estão acima do esperado.
        </p>
        <div className="segmentado" style={{ marginTop: 12 }}>
          <span className="rotulo" style={{ margin: 0 }}>
            Tamanho da janela
          </span>
          {JANELAS.map((j) => (
            <button
              key={j.anos}
              className={`chip${anosPorJanela === j.anos ? ' ativo' : ''}`}
              disabled={j.anos > disponiveis}
              onClick={() => setAnosPorJanela(j.anos)}
              style={
                anosPorJanela === j.anos
                  ? { borderColor: CORES.vermelhoClaro, color: CORES.vermelhoClaro }
                  : undefined
              }
            >
              {j.texto}
            </button>
          ))}
        </div>
      </div>
      <div className="trio">
        {ordem_metodos.map((nome) => (
          <PainelJanela
            key={nome}
            metodo={metodos[nome]}
            cor={COR_METODO[nome]}
            serie={porMetodo[nome]}
            dominioY={dominioY}
            esperado={esperado}
          />
        ))}
      </div>
    </section>
  )
}

export function Aderencia({ dados }) {
  const { metodos, ordem_metodos, parametros } = dados
  const alpha = 1 - parametros.confianca
  const [foco, setFoco] = useState(ordem_metodos[0])

  const piores = useMemo(() => {
    const serie = metodos[foco].backtest.serie
    return serie
      .filter((d) => d.violacao)
      .map((d) => ({ ...d, excesso: -(d.retorno - d.var) }))
      .sort((a, b) => b.excesso - a.excesso)
      .slice(0, 8)
  }, [metodos, foco])

  return (
    <div className="cartao">
      <h3>Aderência do modelo</h3>
      <p className="legenda">
        Teste de Kupiec (POF), cobertura incondicional. H₀: a taxa de violações é igual a{' '}
        {pct(alpha, 1)}. p-valor abaixo de 0,05 rejeita H₀ — o modelo está mal calibrado, seja por
        furar demais (subestima risco) ou de menos (capital parado à toa).
      </p>

      <table>
        <thead>
          <tr>
            <th>Método</th>
            <th style={{ textAlign: 'right' }}>Violações</th>
            <th style={{ textAlign: 'right' }}>Taxa obs.</th>
            <th style={{ textAlign: 'right' }}>Maior seq.</th>
            <th style={{ textAlign: 'right' }}>LR</th>
            <th style={{ textAlign: 'right' }}>p-valor</th>
            <th style={{ textAlign: 'right' }}>Veredito</th>
          </tr>
        </thead>
        <tbody>
          {ordem_metodos.map((nome) => {
            const r = metodos[nome].backtest.resumo
            const rejeita = r.kupiec.rejeita_5pct
            return (
              <tr key={nome}>
                <td style={{ color: COR_METODO[nome], fontWeight: 500 }}>
                  {metodos[nome].rotulo}
                </td>
                <td className="num">
                  {r.violacoes} / {num(r.violacoes_esperadas, 1)}
                </td>
                <td className="num">{pct(r.taxa_observada)}</td>
                <td className="num">{r.maior_sequencia}</td>
                <td className="num">{num(r.kupiec.estatistica_lr)}</td>
                <td className="num">{num(r.kupiec.p_valor, 3)}</td>
                <td className="num">
                  <span className={`selo-teste ${rejeita ? 'falha' : 'ok'}`}>
                    {rejeita ? 'rejeita H₀' : 'não rejeita'}
                  </span>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>

      <div className="separador" />

      <div className="segmentado">
        <span className="rotulo" style={{ margin: 0 }}>
          Maiores excessos
        </span>
        {ordem_metodos.map((nome) => (
          <button
            key={nome}
            className={`chip${foco === nome ? ' ativo' : ''}`}
            onClick={() => setFoco(nome)}
            style={
              foco === nome
                ? { borderColor: COR_METODO[nome], color: COR_METODO[nome] }
                : undefined
            }
          >
            {metodos[nome].rotulo}
          </button>
        ))}
      </div>

      <table>
        <thead>
          <tr>
            <th>Data</th>
            <th style={{ textAlign: 'right' }}>Retorno</th>
            <th style={{ textAlign: 'right' }}>Limite VaR</th>
            <th style={{ textAlign: 'right' }}>Excesso</th>
          </tr>
        </thead>
        <tbody>
          {piores.length === 0 && (
            <tr>
              <td colSpan={4}>Nenhuma violação no período.</td>
            </tr>
          )}
          {piores.map((d) => (
            <tr key={d.data}>
              <td>{dataCurta(d.data)}</td>
              <td className="num perda">{pct(d.retorno)}</td>
              <td className="num">{pct(d.var)}</td>
              <td className="num">{pct(-d.excesso)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
